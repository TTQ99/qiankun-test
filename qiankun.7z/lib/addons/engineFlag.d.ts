/**
 * @author Kuitos
 * @since 2020-05-15
 */
import type { FrameworkLifeCycles } from '../interfaces';
export default function getAddOn(global: Window): FrameworkLifeCycles<any>;
