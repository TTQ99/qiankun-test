/**
 * @author Kuitos
 * @since 2019-11-12
 */
import type { FrameworkLifeCycles } from '../interfaces';
export default function getAddOn(global: Window, publicPath?: string): FrameworkLifeCycles<any>;
