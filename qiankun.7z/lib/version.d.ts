export declare const version = "2.6.3";
