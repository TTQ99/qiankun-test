/**
 * @author Kuitos
 * @since 2019-04-11
 */
export default function patch(global: Window): () => (...args: any[]) => void;
