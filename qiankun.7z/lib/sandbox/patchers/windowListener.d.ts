/**
 * @author Kuitos
 * @since 2019-04-11
 */
export default function patch(global: WindowProxy): () => (...args: any[]) => void;
