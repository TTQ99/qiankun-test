/**
 * @author Kuitos
 * @since 2020-10-13
 */
export { patchLooseSandbox } from './forLooseSandbox';
export { patchStrictSandbox } from './forStrictSandbox';
