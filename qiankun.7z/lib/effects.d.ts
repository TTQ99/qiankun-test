export declare function setDefaultMountApp(defaultAppLink: string): void;
export declare function runDefaultMountEffects(defaultAppLink: string): void;
export declare function runAfterFirstMounted(effect: () => void): void;
