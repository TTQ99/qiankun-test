export declare class QiankunError extends Error {
    constructor(message: string);
}
